"""Minimal additive import rebind from the historical N12 API to R2 bytes.

The scientific gates and downstream algorithms are unchanged.  This adapter is
activated by the R2 package bootstrap before any N13-20 or behavior-v2 consumer
is imported, so their exact run identities bind to the R2 feature run.
"""

from __future__ import annotations

import importlib
import sys
from typing import Any

import stage6_expanded_feature_freeze_v2 as feature_freeze_v2


DOWNSTREAM_CONSUMER_MODULES_V2 = (
    "stage6_expanded_tournament",
    "stage6_expanded_finalist",
    "stage6_expanded_adjudication",
    "stage6_behavior_challenger_notebook_runtime_v2",
    "stage6_behavior_challenger_finalist_v2",
    "stage6_behavior_challenger_fresh_adjudication_v2",
)


def activate_downstream_rebind_v2() -> dict[str, Any]:
    existing = sys.modules.get("stage6_expanded_feature_freeze")
    if existing is not None and existing is not feature_freeze_v2:
        raise RuntimeError(
            "R2 feature rebind must activate before the historical N12 module is imported"
        )
    sys.modules["stage6_expanded_feature_freeze"] = feature_freeze_v2
    rebound: list[str] = []
    for name in DOWNSTREAM_CONSUMER_MODULES_V2:
        try:
            module = importlib.import_module(name)
        except ModuleNotFoundError:
            # Some compact node packages intentionally omit unrelated later
            # consumers; every member that is present is still rebound.
            continue
        if hasattr(module, "FEATURE_RUN_ID"):
            setattr(module, "FEATURE_RUN_ID", feature_freeze_v2.FEATURE_RUN_ID_V2)
        if hasattr(module, "SCIENCE_IMPLEMENTATION_DIGEST"):
            setattr(
                module,
                "SCIENCE_IMPLEMENTATION_DIGEST",
                feature_freeze_v2.R2_IMPLEMENTATION_DIGEST,
            )
        rebound.append(name)
    return {
        "schema_version": "stage6_expanded_downstream_rebind_receipt_v2",
        "feature_run_id": feature_freeze_v2.FEATURE_RUN_ID_V2,
        "r2_implementation_self_sha256": feature_freeze_v2.R2_IMPLEMENTATION_DIGEST,
        "rebound_modules": rebound,
        "gate_logic_changed": False,
        "historical_r1_source_bytes_mutated": False,
        "historical_r1_implementation_hash_emitted": False,
    }

