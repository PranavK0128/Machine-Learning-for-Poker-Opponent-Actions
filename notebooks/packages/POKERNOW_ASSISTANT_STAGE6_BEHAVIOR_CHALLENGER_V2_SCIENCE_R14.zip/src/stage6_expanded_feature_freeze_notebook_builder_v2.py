"""Build the additive exact R5 package and Notebook 12 feature-freeze node."""

from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

import nbformat

from stage6_expanded_feature_freeze_v2 import (
    FEATURE_RUN_ID_V2,
    R5_PACKAGE_PRECOMMIT,
    R2_EQUIVALENCE_GATE_SPEC,
    R2_IMPLEMENTATION_BINDING,
    R2_IMPLEMENTATION_DIGEST,
)
from stage6_expanded_layers import PINNED_RUNTIME_DISTRIBUTIONS, canonical_json_bytes, seal_document
from stage6_notebooks02_07_runtime import sha256_file


STAGE6_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_NAME_V5 = "POKERNOW_ASSISTANT_STAGE6_EXPANDED_FEATURE_FREEZE_INPUTS_R5.zip"
NOTEBOOK_NAME_V5 = "12_Stage6_Expanded_Layer_Causal_Feature_Freeze_R5.ipynb"
STATIC_MANIFEST_NAME_V5 = "stage6_notebook12_static_manifest_r5.json"
# Compatibility exports for callers of the additive builder module.
PACKAGE_NAME_V2 = PACKAGE_NAME_V5
NOTEBOOK_NAME_V2 = NOTEBOOK_NAME_V5
STATIC_MANIFEST_NAME_V2 = STATIC_MANIFEST_NAME_V5
SOURCE_MEMBERS_V2 = (
    "stage6_common.py",
    "stage6_metrics.py",
    "stage6_notebooks02_07_runtime.py",
    "stage6_notebook01_materializer.py",
    "stage6_behavior_tournament.py",
    "stage6_expanded_layers.py",
    "stage6_expanded_feature_freeze.py",
    "stage6_expanded_tournament.py",
    "stage6_expanded_finalist.py",
    "stage6_expanded_adjudication.py",
    "stage6_expanded_diagnostics_adapter.py",
    "stage6_expanded_notebook_controller.py",
    "stage6_expanded_history_acceleration_v2.py",
    "stage6_expanded_feature_freeze_v2.py",
    "stage6_expanded_downstream_rebind_v2.py",
)
CONTRACT_MEMBERS_V2 = (
    "stage6_data_contract_v1.json",
    "stage6_split_contract_v1.json",
    "stage6_scientific_gate_v1.json",
    "stage6_worker_policy_v3.json",
    "stage6_expanded_predictive_layers_contract_v1.json",
)


def _fixed_zip(path: Path, members: list[tuple[str, bytes]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in members:
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts or "\\" in name:
                raise RuntimeError(f"unsafe R2 package member: {name}")
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, raw)


def _write_exact(path: Path, raw: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            raise RuntimeError(f"conflicting frozen R2 artifact exists: {path}")
        return
    with path.open("xb") as target:
        target.write(raw)
        target.flush()
        os.fsync(target.fileno())


def _package(path: Path) -> dict[str, Any]:
    members: list[tuple[str, bytes]] = []
    for name in SOURCE_MEMBERS_V2:
        members.append((f"src/{name}", (STAGE6_ROOT / "src" / name).read_bytes()))
    for name in CONTRACT_MEMBERS_V2:
        members.append((f"contracts/{name}", (STAGE6_ROOT / "contracts" / name).read_bytes()))
    precommit = R5_PACKAGE_PRECOMMIT
    members.append(("r5_feature_freeze_precommit.json", canonical_json_bytes(precommit) + b"\n"))
    package_manifest = seal_document({
        "schema_version": "stage6_expanded_feature_freeze_input_package_manifest_v5",
        "revision": "R5",
        "feature_run_id": FEATURE_RUN_ID_V2,
        "r2_implementation_self_sha256": R2_IMPLEMENTATION_DIGEST,
        "r2_equivalence_gate_spec_self_sha256": R2_EQUIVALENCE_GATE_SPEC["self_sha256"],
        "precommit_self_sha256": precommit["self_sha256"],
        "member_order": [name for name, _ in members],
        "members": [
            {"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
            for name, raw in members
        ],
        "historical_r1_source_bytes_mutated": False,
        "historical_r1_implementation_hash_emitted": False,
        "fresh_targets_opened": False,
        "qualification_authority": False,
    })
    members.append(("PACKAGE_MANIFEST.json", canonical_json_bytes(package_manifest) + b"\n"))
    temporary = path.with_name(f".{path.name}.tmp")
    _fixed_zip(temporary, members)
    raw = temporary.read_bytes()
    temporary.unlink()
    _write_exact(path, raw)
    return {
        "name": path.name,
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
        "package_manifest_self_sha256": package_manifest["self_sha256"],
        "precommit_self_sha256": precommit["self_sha256"],
    }


def _code(value: str) -> Any:
    return nbformat.v4.new_code_cell(value.strip() + "\n")


def _markdown(value: str) -> Any:
    return nbformat.v4.new_markdown_cell(value)


def _bootstrap_code(package: Mapping[str, Any]) -> str:
    pinned_versions = {distribution: version for distribution, _, version in PINNED_RUNTIME_DISTRIBUTIONS}
    pinned_modules = {distribution: module for distribution, module, _ in PINNED_RUNTIME_DISTRIBUTIONS}
    return f'''import hashlib
import importlib.metadata
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[variable] = "1"

PINNED_RUNTIME_DISTRIBUTIONS = {json.dumps(pinned_versions, sort_keys=True)}
PINNED_RUNTIME_MODULES = {json.dumps(pinned_modules, sort_keys=True)}
mismatched = {{
    distribution: version
    for distribution, version in PINNED_RUNTIME_DISTRIBUTIONS.items()
    if importlib.util.find_spec(PINNED_RUNTIME_MODULES[distribution]) is None
    or importlib.metadata.version(distribution) != version
}}
preloaded = [PINNED_RUNTIME_MODULES[name] for name in mismatched if PINNED_RUNTIME_MODULES[name] in sys.modules]
if mismatched:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "--upgrade", *[f"{{name}}=={{version}}" for name, version in PINNED_RUNTIME_DISTRIBUTIONS.items()]])
if preloaded:
    raise RuntimeError("PINNED_ENVIRONMENT_RESTART_REQUIRED: restart and Run all; " + ",".join(preloaded))

try:
    from google.colab import drive
except ImportError as error:
    raise RuntimeError("This release notebook is intended for Google Colab") from error
drive.mount("/content/drive")
STAGE6_DRIVE_ROOT = Path("/content/drive/MyDrive/Poker Assistant Model/Stage 6 - Qualified Layers Improvement")
PACKAGE_PATH = STAGE6_DRIVE_ROOT / "inputs" / "{PACKAGE_NAME_V5}"
EXPECTED_PACKAGE_SHA256 = "{package['sha256']}"
if hashlib.sha256(PACKAGE_PATH.read_bytes()).hexdigest() != EXPECTED_PACKAGE_SHA256:
    raise RuntimeError("R5 expanded feature package SHA-256 mismatch")
PACKAGE_ROOT = Path("/content/stage6_expanded_feature_freeze_r5")
if PACKAGE_ROOT.exists():
    shutil.rmtree(PACKAGE_ROOT)
PACKAGE_ROOT.mkdir(parents=True)
with zipfile.ZipFile(PACKAGE_PATH) as archive:
    names = archive.namelist()
    if not names or names[-1] != "PACKAGE_MANIFEST.json" or len(names) != len(set(names)):
        raise RuntimeError("invalid R5 package membership")
    for name in names:
        pure = PurePosixPath(name)
        if pure.is_absolute() or ".." in pure.parts or "\\\\" in name:
            raise RuntimeError(f"unsafe package member: {{name}}")
    archive.extractall(PACKAGE_ROOT)
package_manifest = json.loads((PACKAGE_ROOT / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
for member in package_manifest["members"]:
    raw = (PACKAGE_ROOT / member["path"]).read_bytes()
    if len(raw) != member["bytes"] or hashlib.sha256(raw).hexdigest() != member["sha256"]:
        raise RuntimeError(f"R5 package member identity mismatch: {{member['path']}}")
sys.path.insert(0, str(PACKAGE_ROOT / "src"))
from stage6_expanded_downstream_rebind_v2 import activate_downstream_rebind_v2
R2_DOWNSTREAM_REBIND = activate_downstream_rebind_v2()
print(json.dumps({{"event": "stage6_expanded_feature_r5_ready", "package_sha256": EXPECTED_PACKAGE_SHA256, "tree_history_execution": "host_cpu_process_work", "tpu_acceleration_claimed": False}}, sort_keys=True))'''


def _notebook(package: Mapping[str, Any]) -> Any:
    cells = [
        _markdown("""# Stage 6 — Expanded Layer Causal Feature Freeze R5

**Notebook 12 · atomic claim-cleanup recovery repair R5**

CPU High-RAM is preferred because this notebook performs host-CPU causal feature engineering, not model-heavy training. CPU, GPU, and TPU sessions remain portable, and no accelerator use is claimed. R5 preserves all R4 causal/scientific and crash-recovery gates and atomically retires completed JSON claims before resumable tombstone cleanup. Fresh targets and action timing remain excluded."""),
        _markdown("## Operator settings"),
        _code('''import os
REQUESTED_WORKERS = "auto"  # @param {type:"string"}
ACCELERATOR_ENVIRONMENT = "CPU"  # @param ["CPU", "GPU", "TPU"]
REQUESTED_WORKERS = os.environ.get("STAGE6_REQUESTED_WORKERS", REQUESTED_WORKERS).strip()
if REQUESTED_WORKERS != "auto":
    if int(REQUESTED_WORKERS) < 1:
        raise ValueError("REQUESTED_WORKERS must be auto or a positive integer")
print({"requested_workers": REQUESTED_WORKERS, "accelerator_environment": ACCELERATOR_ENVIRONMENT, "preferred_host": "CPU High-RAM", "execution": "host_cpu_process_work", "accelerator_acceleration_claimed": False})'''),
        _markdown("## Mount Drive and verify the exact R5 package"),
        _code(_bootstrap_code(package)),
        _markdown("## Run exact-equivalence preflight and the R2 feature freeze"),
        _code('''from stage6_expanded_feature_freeze_v2 import FEATURE_RUN_ID_V2, run_feature_freeze_v2
result = run_feature_freeze_v2(STAGE6_DRIVE_ROOT, REQUESTED_WORKERS, ACCELERATOR_ENVIRONMENT)
RUN_IDENTITY = FEATURE_RUN_ID_V2
PRIMARY_MANIFEST_PATH = Path(result["manifest_path"])
result'''),
        _markdown("## Publish and download the compact returned result"),
        _code('''from stage6_expanded_notebook_controller import publish_compact_result
returned_result = publish_compact_result(
    STAGE6_DRIVE_ROOT, token="12-r5", run_identity=RUN_IDENTITY,
    result=result, primary_manifest_path=PRIMARY_MANIFEST_PATH,
)
print(returned_result)
try:
    from google.colab import files
    files.download(returned_result["path"])
except Exception as error:
    print({"download_status": "manual_download_may_be_required", "detail": str(error), "path": returned_result["path"]})'''),
    ]
    notebook = nbformat.v4.new_notebook(
        cells=cells,
        metadata={
            "colab": {"name": NOTEBOOK_NAME_V5, "provenance": []},
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python", "version": "3"},
            "stage6": {
                "token": "12-r5", "revision": "R5", "depends_on": [],
                "runtime_preference": "CPU High-RAM",
                "accepted_runtime_types": ["cpu", "gpu", "tpu"],
                "feature_derivation_execution": "host_cpu_process_work",
                "tpu_acceleration_claimed": False,
                "requested_workers_default": "auto",
                "worker_boundaries": ["logical_cpu", "unfinished_partitions", "available_ram"],
                "heartbeat_interval_seconds": 60,
                "logical_data_lane_count": 48,
                "action_timing_layer_included": False,
                "fresh_targets_opened": False,
                "qualification_authority": False,
            },
        },
    )
    for index, cell in enumerate(notebook.cells):
        cell["id"] = hashlib.sha256(
            f"stage6-expanded-feature-r5:12:{index}:{cell.cell_type}:{cell.source}".encode("utf-8")
        ).hexdigest()[:8]
    nbformat.validate(notebook)
    return notebook


def build_release_v5() -> dict[str, Any]:
    package_path = STAGE6_ROOT / "inputs" / PACKAGE_NAME_V5
    package = _package(package_path)
    notebook = _notebook(package)
    notebook_path = STAGE6_ROOT / "notebooks" / NOTEBOOK_NAME_V5
    _write_exact(notebook_path, nbformat.writes(notebook).encode("utf-8"))
    notebook_identity = {
        "name": notebook_path.name,
        "bytes": notebook_path.stat().st_size,
        "sha256": sha256_file(notebook_path),
    }
    static = seal_document({
        "schema_version": "stage6_expanded_notebook_static_manifest_v5",
        "revision": "R5",
        "notebook_token": "12-r5",
        "notebook": notebook_identity,
        "shared_package": package,
        "feature_run_id": FEATURE_RUN_ID_V2,
        "r2_implementation_self_sha256": R2_IMPLEMENTATION_DIGEST,
        "r2_equivalence_gate_spec_self_sha256": R2_EQUIVALENCE_GATE_SPEC["self_sha256"],
        "downstream_rebind_module": "stage6_expanded_downstream_rebind_v2",
        "runtime_preference": "CPU High-RAM",
        "accepted_runtime_types": ["CPU", "GPU", "TPU"],
        "feature_derivation_execution": "host_cpu_process_work",
        "tpu_acceleration_claimed": False,
        "requested_workers_default": "auto",
        "heartbeat_interval_seconds": 60,
        "logical_data_lane_count": 48,
        "historical_r1_source_bytes_mutated": False,
        "historical_r1_implementation_hash_emitted": False,
        "action_timing_layer_included": False,
        "fresh_targets_opened": False,
        "qualification_authority": False,
    })
    static_path = STAGE6_ROOT / "manifests" / STATIC_MANIFEST_NAME_V5
    _write_exact(
        static_path,
        json.dumps(static, indent=2, sort_keys=True, ensure_ascii=False).encode("utf-8") + b"\n",
    )
    return {
        "package": package,
        "notebook": notebook_identity,
        "static_manifest": {
            "name": static_path.name,
            "bytes": static_path.stat().st_size,
            "sha256": sha256_file(static_path),
            "self_sha256": static["self_sha256"],
        },
    }


def build_release_v2() -> dict[str, Any]:
    """Compatibility entrypoint; emits only the non-overwriting R5 release."""
    return build_release_v5()


if __name__ == "__main__":
    print(json.dumps(build_release_v5(), indent=2, sort_keys=True))
