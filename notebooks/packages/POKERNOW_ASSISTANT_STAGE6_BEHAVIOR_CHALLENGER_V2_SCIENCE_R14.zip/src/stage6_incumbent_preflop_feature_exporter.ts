import path from "node:path";
import type { Prisma } from "@prisma/client";
import { disconnectPrisma, prisma } from "../../../packages/db/src/index";
import {
    type ExportTextWriter,
    writeExportStreamedTextFile
} from "../../../scripts/export/exportFileWriter";


const STAGE6_ROOT = path.resolve(
    "C:/Users/konda/Stack Society PokerNow Analyzer/Poker Assistant Model/Stage 6 - Qualified Layers Improvement"
);
const OUTPUT_PATH = path.join(
    STAGE6_ROOT,
    "data",
    "exports",
    "ml",
    "stage6-incumbent-preflop-native-features.csv"
);
const BATCH_SIZE = 5_000;
const STAGE6_PREFLOP_FEATURE_SELECT = {
    id: true,
    handId: true,
    pokernowGameId: true,
    pokernowHandId: true,
    pokernowPlayerId: true,
    decisionType: true,
    stakeLabel: true,
    position: true,
    positionGroup: true,
    primaryOpportunity: true,
    facingSituation: true,
    openerPosition: true,
    threeBettorPosition: true,
    seat: true,
    stackBb: true,
    rfiOpportunity: true,
    stealOpportunity: true,
    coldCallOpportunity: true,
    threeBetOpportunity: true,
    squeezeOpportunity: true,
    foldToStealOpportunity: true,
    facedOpenRaise: true,
    facedThreeBet: true,
    facedFourBet: true,
    foldToFourBetOpportunity: true,
    openRaiseAmountBb: true,
    threeBetToAmountBb: true,
    priorLimperCount: true,
    priorCallerCount: true,
    playersLeftToAct: true
} as const;
type Stage6PreflopFeatureRow = Prisma.MlPreflopDecisionRowGetPayload<{
    select: typeof STAGE6_PREFLOP_FEATURE_SELECT;
}>;


function csvEscape(value: unknown): string {
    if (value === null || value === undefined) {
        return "";
    }
    const text = String(value);
    return /[",\r\n]/.test(text)
        ? `"${text.replaceAll("\"", "\"\"")}"`
        : text;
}


function boolToCsv(value: boolean): string {
    return value ? "1" : "0";
}


async function exportFeatureRows(): Promise<void> {
    if (
        path.resolve(process.cwd()) !== STAGE6_ROOT ||
        STAGE6_ROOT.toLowerCase().includes("onedrive")
    ) {
        throw new Error(`run from the canonical Stage 6 root: ${STAGE6_ROOT}`);
    }
    const headers = [
        "hand_id",
        "pokernowGameId",
        "pokernowHandId",
        "pokernowPlayerId",
        "decisionType",
        "stakeLabel",
        "position",
        "positionGroup",
        "primaryOpportunity",
        "facingSituation",
        "openerPosition",
        "threeBettorPosition",
        "seat",
        "stackBb",
        "rfiOpportunity",
        "stealOpportunity",
        "coldCallOpportunity",
        "threeBetOpportunity",
        "squeezeOpportunity",
        "foldToStealOpportunity",
        "facedOpenRaise",
        "facedThreeBet",
        "facedFourBet",
        "foldToFourBetOpportunity",
        "openRaiseAmountBb",
        "threeBetToAmountBb",
        "priorLimperCount",
        "priorCallerCount",
        "playersLeftToAct"
    ];
    let cursorId: string | null = null;
    let exportedRows = 0;
    const result = await writeExportStreamedTextFile(
        OUTPUT_PATH,
        async (writer: ExportTextWriter): Promise<void> => {
            await writer.write(`${headers.join(",")}\n`);
            for (;;) {
                const rows: Stage6PreflopFeatureRow[] = await prisma.mlPreflopDecisionRow.findMany({
                    select: STAGE6_PREFLOP_FEATURE_SELECT,
                    orderBy: { id: "asc" },
                    ...(cursorId === null
                        ? {}
                        : { cursor: { id: cursorId }, skip: 1 }),
                    take: BATCH_SIZE
                });
                if (rows.length === 0) {
                    return;
                }
                cursorId = rows[rows.length - 1].id;
                for (const row of rows) {
                    if (row.seat === null) {
                        throw new Error(`${row.id}: incumbent preflop row has no seat`);
                    }
                    const values = [
                        row.handId,
                        row.pokernowGameId,
                        row.pokernowHandId,
                        row.pokernowPlayerId,
                        row.decisionType,
                        row.stakeLabel,
                        row.position,
                        row.positionGroup,
                        row.primaryOpportunity,
                        row.facingSituation,
                        row.openerPosition,
                        row.threeBettorPosition,
                        row.seat,
                        row.stackBb?.toString() ?? null,
                        boolToCsv(row.rfiOpportunity),
                        boolToCsv(row.stealOpportunity),
                        boolToCsv(row.coldCallOpportunity),
                        boolToCsv(row.threeBetOpportunity),
                        boolToCsv(row.squeezeOpportunity),
                        boolToCsv(row.foldToStealOpportunity),
                        boolToCsv(row.facedOpenRaise),
                        boolToCsv(row.facedThreeBet),
                        boolToCsv(row.facedFourBet),
                        boolToCsv(row.foldToFourBetOpportunity),
                        row.openRaiseAmountBb?.toString() ?? null,
                        row.threeBetToAmountBb?.toString() ?? null,
                        row.priorLimperCount,
                        row.priorCallerCount,
                        row.playersLeftToAct
                    ];
                    await writer.write(`${values.map(csvEscape).join(",")}\n`);
                    exportedRows += 1;
                }
                if (exportedRows % 100_000 === 0) {
                    console.log(JSON.stringify({
                        event: "stage6_incumbent_preflop_feature_progress",
                        exported_rows: exportedRows
                    }));
                }
            }
        }
    );
    console.log(JSON.stringify({
        event: "stage6_incumbent_preflop_feature_complete",
        exported_rows: exportedRows,
        output_path: result.outputPath,
        used_fallback_path: result.usedFallbackPath
    }));
}


exportFeatureRows()
    .catch((error: unknown) => {
        console.error(error);
        process.exitCode = 1;
    })
    .finally(async () => {
        await disconnectPrisma();
    });
