"""Small semantic fixtures only; synthetic models never confer authority."""
import copy
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import stage7_hierarchical_response_v1 as h


def stamp(seconds):
    return (datetime(2026, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=seconds)).isoformat().replace("+00:00", "Z")


def row(index, *, game="g1", actor="p1", session="s1", decision=None,
        completed=None, action="call", size=.5):
    decision = index * 10 if decision is None else decision
    completed = decision + 5 if completed is None else completed
    public = dict.fromkeys(h.incumbent.NUMERIC, 1.0)
    public.update(street="preflop", board=[], position="BTN", opportunity="facing_open",
                  effective_stack_before_bb=180, active_opponent_count_before=2)
    start = 0 if game == "g1" else 1000
    end = 999 if game == "g1" else 1999
    return dict(row_id=f"{game}_r{index:05d}", game_id=game, hand_id=f"h{index}", actor_id=actor,
                session_id=session, game_started_utc=stamp(start), game_completed_utc=stamp(end),
                decision_utc=stamp(decision), public_available_utc=stamp(decision),
                action_observed_utc=stamp(decision + 1), hand_completed_utc=stamp(completed),
                public=public, action=action, legal_actions=list(h.LABELS[h.ACTION]),
                observed_action_size_pot_fraction=size, card_visibility={"state": "latent"})


def stream(rows):
    return list(h.causal_feature_stream(
        sorted(rows, key=lambda r: (h.incumbent.utc(r["decision_utc"]), r["row_id"])),
        sorted(rows, key=lambda r: (h.incumbent.utc(r["hand_completed_utc"]), r["row_id"]))))


def test_strict_completion_ties_and_current_hand_are_excluded():
    first = row(1, decision=10, completed=30, action="fold")
    same_hand = row(2, decision=20, completed=30, action="raise")
    same_hand["hand_id"] = first["hand_id"]
    tied = row(3, decision=30, completed=35)
    later = row(4, decision=40, completed=45)
    results = stream([later, tied, same_hand, first])
    assert [r[2]["counts"][0] for r in results] == [0, 0, 0, 3]
    assert results[2][2]["latest_history_completion"] is None
    assert results[3][2]["latest_history_completion"] == h.incumbent.utc(stamp(35))


def test_history_counts_match_independent_bruteforce_oracle():
    rows = [row(i, actor=f"p{i % 3}", action=h.LABELS[h.ACTION][i % 6],
                decision=i * 10, completed=i * 10 + (25 if i % 2 else 5)) for i in range(1, 20)]
    for current, features, audit in stream(rows):
        prior = [r for r in rows if h.incumbent.utc(r["hand_completed_utc"]) < h.incumbent.utc(current["decision_utc"])]
        own = [r for r in prior if r["actor_id"] == current["actor_id"]]
        population_counts = np.array([sum(r["action"] == action for r in prior) for action in h.LABELS[h.ACTION]])
        own_counts = np.array([sum(r["action"] == action for r in own) for action in h.LABELS[h.ACTION]])
        broad = (population_counts + 1) / (len(prior) + 6)
        population = (population_counts + 100 * broad) / (len(prior) + 100)
        player = (own_counts + 100 * population) / (len(own) + 100)
        names = h.feature_names(h.ACTION, "player")
        actual = [features[h.ACTION]["player"][names.index("player_rate_" + action)] for action in h.LABELS[h.ACTION]]
        np.testing.assert_allclose(actual, player)
        assert audit["counts"] == [len(prior), len(prior), len(own), len(own)]


def test_future_target_mutations_cannot_change_earlier_features():
    rows = [row(i, action="raise") for i in range(1, 6)]
    changed = copy.deepcopy(rows)
    changed[-1].update(action="bet", observed_action_size_pot_fraction=7)
    before, after = stream(rows), stream(changed)
    assert [r[1] for r in before[:-1]] == [r[1] for r in after[:-1]]
    assert before[-1][1][h.ACTION] == after[-1][1][h.ACTION]


def test_action_features_cannot_read_observed_action_size_or_private_cards():
    current = row(1)
    changed = copy.deepcopy(current)
    changed.update(action="raise", observed_action_size_pot_fraction=99,
                   card_visibility={"state": "revealed_after_decision", "hole_cards": ["As", "Ah"]})
    for arm in h.ARMS:
        assert h.feature_vector(current, h.ACTION, arm, h.History()) == h.feature_vector(changed, h.ACTION, arm, h.History())
    assert h.context_key(current, h.ACTION) == h.context_key(changed, h.ACTION)


def test_size_features_condition_on_action_but_never_current_size():
    small = row(1, action="raise", size=.2)
    large = dict(small, observed_action_size_pot_fraction=3)
    for arm in h.ARMS:
        assert h.feature_vector(small, h.SIZE, arm, h.History()) == h.feature_vector(large, h.SIZE, arm, h.History())
    assert h.target(small, h.SIZE) == 0 and h.target(large, h.SIZE) == 2
    assert h.target(row(2, action="call"), h.SIZE) is None


def test_session_reset_and_exact_actor_identity():
    previous = row(1, actor="p1", action="fold")
    current = row(2, game="g2", actor="p1", decision=1010)
    state = h.History(); state.observe(previous)
    summary = state.summary(current, h.ACTION)
    assert summary["counts"] == [1, 1, 1, 0]
    assert summary["age_days"] == pytest.approx((1010 - 15) / 86400)
    unknown = state.summary(dict(current, actor_id="different-exact-id"), h.ACTION)
    assert unknown["counts"] == [1, 1, 0, 0] and unknown["unseen"]
    np.testing.assert_allclose(unknown["player"], unknown["population"])


def test_opportunity_and_legal_denominators_do_not_mix():
    prior = row(1, action="fold")
    current = row(2)
    current["legal_actions"] = ["check", "bet"]
    current["action"] = "check"
    state = h.History(); state.observe(prior)
    summary = state.summary(current, h.ACTION)
    assert summary["counts"] == [0, 0, 0, 0]
    assert summary["population"][h.LABELS[h.ACTION].index("fold")] == 0
    assert summary["population"][h.LABELS[h.ACTION].index("check")] == .5
    another = row(3)
    another["public"]["opportunity"] = "squeeze"
    assert state.summary(another, h.ACTION)["counts"] == [1, 0, 0, 0]


@pytest.mark.parametrize("mutation", [
    {"actor_id": ""}, {"hand_completed_utc": stamp(9)},
    {"public_available_utc": stamp(11)}, {"action_observed_utc": stamp(16)},
    {"legal_actions": ["fold"]}, {"action": "raise", "observed_action_size_pot_fraction": float("nan")},
])
def test_invalid_source_contract_fails_closed(mutation):
    with pytest.raises(ValueError):
        h.validate_observation(dict(row(1), **mutation))


def test_duplicate_decisions_and_observations_are_rejected():
    one, two = row(1), row(2)
    with pytest.raises(ValueError, match="decisions_not_unique"):
        list(h.causal_feature_stream([one, one], []))
    with pytest.raises(ValueError, match="observations_not_unique"):
        list(h.causal_feature_stream([two], [one, one]))


def test_direct_state_query_cannot_bypass_chronology():
    state = h.History(); state.observe(row(1))
    with pytest.raises(ValueError, match="history_not_strictly"):
        state.summary(row(2, decision=15), h.ACTION)


def test_frozen_joint_probability_projection_and_size_conditioning():
    labels = ["fold@none", "raise@small", "raise@medium", "raise@large", "bet@small", "bet@medium", "bet@large"]
    p = np.array([[.4, .1, .2, .1, .1, .05, .05]])
    current = row(1, action="raise")
    action = h.collapse_incumbent(p, labels, [current], h.ACTION)
    np.testing.assert_allclose(action, [[.4, 0, 0, .2, .4, 0]])
    sizes = h.collapse_incumbent(p, labels, [current], h.SIZE)
    np.testing.assert_allclose(sizes, [[.25, .5, .25]])
    with pytest.raises(ValueError, match="class_absent"):
        h.collapse_incumbent(p[:, :-4], labels[:-4], [current], h.SIZE)


@pytest.mark.parametrize("class_count", [2, 3, 6])
def test_vectorized_frozen_scorer_matches_native_and_portable(class_count):
    rng = np.random.default_rng(42)
    x = rng.normal(size=(80, 4)); y = np.arange(80) % class_count
    labels = [str(i) for i in range(class_count)]
    config = dict(iterations=5, num_leaves=5, learning_rate=.1, min_child_samples=2, seed=11)
    model = h.incumbent.fit_booster(x, y, labels, config)
    exported = h.incumbent.booster_export(model, labels, ["a", "b", "c", "d"])
    exported["temperature"] = 1.5
    native = h.incumbent.temper(h.incumbent.full_prediction(model, x, labels), 1.5)
    actual = h.batch_tree_prediction(exported, x)
    np.testing.assert_allclose(actual, native, atol=1e-12, rtol=1e-12)
    np.testing.assert_allclose(actual, [h.incumbent.tree_prediction(exported, v) for v in x], atol=1e-12, rtol=1e-12)
    x[0, 0] = np.nan
    np.testing.assert_allclose(h.batch_tree_prediction(exported, x),
                               [h.incumbent.tree_prediction(exported, v) for v in x], atol=1e-12, rtol=1e-12)


def test_fit_separates_calibration_and_preserves_zero_authority():
    training = [row(i, action=h.LABELS[h.ACTION][i % 6]) for i in range(1, 19)]
    calibration = [row(i, game="g2", decision=1000 + i * 10, action=h.LABELS[h.ACTION][i % 6]) for i in range(1, 7)]
    prepared = stream(training + calibration)
    x = [r[1][h.ACTION]["session"] for r in prepared]
    config = dict(iterations=3, num_leaves=3, learning_rate=.1, min_child_samples=1, seed=11)
    artifact, report = h.fit_candidate(x[:18], training, x[18:], calibration, h.ACTION, "session", config)
    assert report["temperature"] in h.TEMPERATURES
    assert artifact["authority"] == h.AUTHORITY and artifact["authority"]["runtime_weight"] == 0
    assert artifact["evidence_class"] == h.EVIDENCE
    assert artifact["trained_game_ids"] == ["g1"] and artifact["calibration_game_ids"] == ["g2"]
    with pytest.raises(ValueError, match="duplicate_fitting_row_id|cohort_overlap"):
        h.fit_candidate(x[:18], training, x[:2], training[:2], h.ACTION, "session", config)


def test_development_plan_retires_old_confirmation_and_reuses_full_incumbent():
    bounds = {f"g{i}": [stamp(i * 1000), stamp(i * 1000 + 999)] for i in range(1, 7)}
    previous = dict(train_game_ids=["g1", "g2", "g3"], calibration_game_ids=["g4"],
                    evaluation_game_ids=["g5"], diagnostic_game_ids=["g6"], model_config={"seed": 1})
    plan = h.development_protocol(previous, bounds)
    assert plan["untouched_confirmation_game_ids"] == []
    assert plan["training_windows"] == {"50": ["g1"], "75": ["g1", "g2"], "100": ["g1", "g2", "g3"]}
    assert plan["full_window_same_recipe"] == "REUSE_ACCEPTED_NOTEBOOK03_MODEL"
    assert plan["evidence_class"] == "DEVELOPMENT_REUSE_ONLY"
    changed = copy.deepcopy(bounds); changed["g3"][1] = changed["g4"][0]
    with pytest.raises(ValueError, match="chronological"):
        h.development_protocol(previous, changed)


@pytest.mark.parametrize("entrypoint", ["direct", "stream", "reused_history"])
def test_audit_same_hand_with_disagreeing_completion_is_rejected(entrypoint):
    prior = row(1, decision=10, completed=25)
    current = row(2, decision=30, completed=35)
    prior["hand_id"] = current["hand_id"] = "shared"
    with pytest.raises(ValueError, match="inconsistent_hand_completion|current_hand"):
        if entrypoint == "stream":
            list(h.causal_feature_stream([current], [prior]))
        else:
            history = h.History(); history.observe(prior)
            if entrypoint == "direct":
                history.summary(current, h.ACTION)
            else:
                list(h.causal_feature_stream([current], [], history))


def test_audit_duplicate_id_at_different_times_is_rejected():
    first, second = row(1, decision=40), row(2, decision=50)
    second["row_id"] = first["row_id"]
    with pytest.raises(ValueError, match="duplicate_decision_row_id"):
        list(h.causal_feature_stream([first, second], []))
    with pytest.raises(ValueError, match="duplicate_observation_row_id"):
        list(h.causal_feature_stream([row(3, decision=80)], [first, second]))


@pytest.mark.parametrize("defect", ["invalid", "duplicate", "reversed"])
def test_audit_trailing_observation_is_validated_without_entering_history(defect):
    first, later = row(1), row(2, decision=60)
    if defect == "invalid":
        tail = [dict(later, legal_actions=["fold"])]
    elif defect == "duplicate":
        tail = [later, dict(row(3, decision=70), row_id=later["row_id"])]
    else:
        tail = [row(3, decision=70), later]
    history = h.History()
    with pytest.raises(ValueError):
        list(h.causal_feature_stream([first], tail, history))
    assert history.observations == 0


@pytest.mark.parametrize("defect", ["illegal_training", "illegal_calibration", "duplicate"])
def test_audit_fit_rejects_invalid_rows_before_fitter(tmp_path, monkeypatch, defect):
    training = [row(1, action="fold"), row(2, action="call")]
    calibration = [row(3, game="g2", decision=1030, action="call")]
    x = [h.feature_vector(r, h.ACTION, "public_only", h.History()) for r in training]
    cx = [h.feature_vector(r, h.ACTION, "public_only", h.History()) for r in calibration]
    if defect == "illegal_training":
        training[0]["legal_actions"] = ["call"]
    elif defect == "illegal_calibration":
        calibration[0]["legal_actions"] = ["fold"]
    else:
        training[1]["row_id"] = training[0]["row_id"]
    called = []
    def prohibited(*args, **kwargs):
        called.append(True)
        raise AssertionError("fitter must not be reached")
    monkeypatch.setattr(h.incumbent, "fit_booster", prohibited)
    with pytest.raises(ValueError, match="invalid_observed_action|duplicate_fitting"):
        h.fit_candidate(x, training, cx, calibration, h.ACTION, "public_only", {})
    assert not called


def test_sparse_training_classes_keep_full_output_schema_and_native_parity():
    x = np.random.default_rng(17).normal(size=(24, len(h.incumbent.PUBLIC_NAMES)))
    y = np.asarray([2, 4] * 12, dtype=np.int16)
    config = dict(iterations=3, num_leaves=3, learning_rate=.1, min_child_samples=1, seed=11)
    model = h.fit_response_booster(x, y, h.ACTION, config)
    exported = h.incumbent.booster_export(model, h.LABELS[h.ACTION], h.incumbent.PUBLIC_NAMES)
    assert exported["fitted_class_indices"] == [2, 4]
    predicted = h.incumbent.full_prediction(model, x, h.LABELS[h.ACTION])
    assert predicted.shape == (24, 6)
    np.testing.assert_allclose(predicted, h.batch_tree_prediction(exported, x), atol=1e-12, rtol=1e-12)
    assert np.all(predicted[:, [0, 1, 3, 5]] < 1e-10)
