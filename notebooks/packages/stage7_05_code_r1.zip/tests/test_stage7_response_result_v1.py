import copy
from pathlib import Path
import shutil
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import stage7_response_result_v1 as result
from test_stage7_response_controller_v1 import execution_plan
from test_stage7_response_assembly_v1 import write_json


@pytest.fixture(scope="module")
def exported(tmp_path_factory):
    base = tmp_path_factory.mktemp("portable_result")
    root, durable, output = base / "runtime", base / "durable", base / "export"
    path, identity, plan = execution_plan(root)
    completion = result.controller.run(path, identity, root, durable, workers=2)
    manifest_identity = result.export(root, durable, path, identity, completion["completion_index"], output)
    return root, durable, output, identity, manifest_identity, completion


def test_compact_export_validates_all_windows_without_training_database(exported):
    _, _, output, plan_identity, manifest_identity, _ = exported
    validated = result.validate(output, manifest_identity, plan_identity)
    assert validated["status"] == "ACCEPT_FOR_DIAGNOSTIC_REVIEW"
    assert validated["completed_units"] == 35
    assert [w["window"] for w in validated["windows"]] == ["50", "75", "100"]
    assert not validated["scientific_qualification"]
    assert not list(output.rglob("*.sqlite"))
    assert len(list(output.rglob("*.npy"))) == 6


def test_transport_and_relocated_import_do_not_fit_infer_prepare_or_regenerate(exported, tmp_path, monkeypatch):
    _, _, output, plan_identity, manifest_identity, _ = exported
    def forbidden(*args, **kwargs):
        raise AssertionError("strict local import must not replay models or regenerate source")
    monkeypatch.setattr(result.h, "batch_tree_prediction", forbidden)
    monkeypatch.setattr(result.h, "fit_response_booster", forbidden)
    monkeypatch.setattr(result.prep, "prepare", forbidden)
    monkeypatch.setattr(result.control, "generate", forbidden)
    monkeypatch.setattr(result.joint, "event_rows", forbidden)
    destination = tmp_path / "transport"
    ref = result.publish(output, manifest_identity, plan_identity, destination)
    imported = result.import_bundle(destination, ref, manifest_identity, plan_identity, tmp_path / "relocated")
    assert not imported["model_replay_performed"]
    assert not imported["preparation_performed"]
    assert imported == result.validate(output, manifest_identity, plan_identity)


@pytest.mark.parametrize("defect", ("manifest_hash", "plan_hash", "missing", "extra", "changed_payload", "authority", "missing_context", "code_hash", "index_hash"))
def test_external_pins_and_exact_inventory_fail_closed(exported, tmp_path, defect):
    _, _, original, plan_identity, manifest_identity, _ = exported
    output = tmp_path / "copy"
    shutil.copytree(original, output)
    manifest = result.t.load(output / result.MANIFEST)
    if defect == "manifest_hash":
        manifest_identity = dict(manifest_identity, sha256="0" * 64)
    elif defect == "plan_hash":
        plan_identity = dict(plan_identity, sha256="0" * 64)
    elif defect == "missing":
        (output / "contexts/50.json").unlink()
    elif defect == "extra":
        (output / "unexpected.txt").write_text("preserve")
    elif defect == "changed_payload":
        (output / "contexts/50.json").write_text("{}")
    else:
        if defect == "authority":
            manifest["authority"] = {"promotion": True}
        elif defect == "missing_context":
            manifest["members"].pop("contexts/50.json")
            (output / "contexts/50.json").unlink()
        elif defect == "code_hash":
            manifest["code_files"][Path(result.__file__).name]["sha256"] = "0" * 64
        else:
            manifest["completion_index"]["identity"]["sha256"] = "0" * 64
        manifest_identity = write_json(output / result.MANIFEST, manifest)
    with pytest.raises((ValueError, FileNotFoundError)):
        result.validate(output, manifest_identity, plan_identity)


@pytest.mark.parametrize("defect", ("duplicate_ordinal", "duplicate_row", "reversed", "wrong_game", "actor_duplicate", "training_count", "prep_pin"))
def test_resealed_context_still_checks_semantics(exported, tmp_path, defect):
    _, _, original, plan_identity, _, _ = exported
    output = tmp_path / "copy"
    shutil.copytree(original, output)
    manifest = result.t.load(output / result.MANIFEST)
    name = "contexts/50.json"
    context = result.t.load(output / name)
    if defect == "duplicate_ordinal":
        context["records"][1][0] = context["records"][0][0]
    elif defect == "duplicate_row":
        context["records"][1][1] = copy.deepcopy(context["records"][0][1])
    elif defect == "reversed":
        context["records"].reverse()
    elif defect == "wrong_game":
        context["records"][0][1]["game_id"] = "not_an_evaluation_game"
    elif defect == "actor_duplicate":
        role = result.h.ACTION
        context["training_actors"][role] += context["training_actors"][role][:1]
    elif defect == "training_count":
        context["training_joint_counts"][next(iter(context["training_joint_counts"]))] += 1
    else:
        context["preparation_identity"]["sha256"] = "0" * 64
    manifest["members"][name] = write_json(output / name, context)
    manifest_identity = write_json(output / result.MANIFEST, manifest)
    with pytest.raises(ValueError):
        result.validate(output, manifest_identity, plan_identity)


def test_existing_export_and_import_are_preserved(exported, tmp_path):
    root, durable, output, plan_identity, _, completion = exported
    with pytest.raises(ValueError, match="existing_output"):
        result.export(root, durable, root / "execution_plan.json", plan_identity, completion["completion_index"], output)
    quarantine = tmp_path / "quarantine"
    quarantine.mkdir()
    (quarantine / "orphan.txt").write_text("preserve")
    with pytest.raises(ValueError, match="empty_quarantine"):
        result.import_bundle(tmp_path / "missing", {}, {}, {}, quarantine)
    assert (quarantine / "orphan.txt").read_text() == "preserve"


def test_copy_rejects_substitution_without_resealing(tmp_path):
    source, target = tmp_path / "source", tmp_path / "target"
    source.write_bytes(b"original")
    identity = result.t.identity(source)
    source.write_bytes(b"modified")
    with pytest.raises(ValueError, match="byte_identity"):
        result.copy_pinned(source, target, identity)
    assert not target.exists()
    assert target.with_name("target.partial").exists()
