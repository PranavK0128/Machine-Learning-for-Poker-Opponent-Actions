import copy
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import stage7_response_controller_v1 as controller
from test_stage7_joint_recipe_v1 import job
from test_stage7_response_assembly_v1 import write_json


def execution_plan(directory):
    directory.mkdir(exist_ok=True)
    args = job(directory, partial_labels=True)
    plan = dict(schema_version=controller.SCHEMA + "_plan", run_id="stage7_hierarchical_response_r1",
        input_contract=dict(path="input_contract.json", identity=args["input_contract_identity"]),
        source_database=dict(path="source.sqlite", identity=controller.t.identity(directory / "source.sqlite")),
        incumbent=dict(path="incumbent.json", identity=args["incumbent_identity"]),
        code_files=controller.code_identities(), windows=["50", "75", "100"])
    path = directory / "execution_plan.json"
    return path, write_json(path, plan), plan


@pytest.fixture(scope="module")
def completed(tmp_path_factory):
    base = tmp_path_factory.mktemp("response_controller")
    root, durable = base / "runtime", base / "durable"
    path, identity, plan = execution_plan(root)
    result = controller.run(path, identity, root, durable, workers=2)
    return root, durable, path, identity, plan, result


def test_controller_executes_exact_35_units_with_fixed_outputs(completed):
    root, durable, path, identity, plan, result = completed
    assert result["completed_units"] == 35
    assert [item["window"] for item in result["windows"]] == ["50", "75", "100"]
    assert result["full_window_refitted"] is False
    assert not (root / "work/controller.lock").exists()
    assert not (root / "work/joint_100").exists()
    assert len(list(durable.glob("index_*.json"))) == 35
    assert len(list(durable.glob("*.checkpoint.json"))) == 35
    for item in result["windows"]:
        controller.t.verify(root / "work" / item["control_receipt"]["path"], item["control_receipt"]["identity"])


def test_cold_restore_reuses_every_completed_unit_without_refit_or_inference(completed, monkeypatch):
    root, durable, path, identity, _, result = completed
    work = root / "work"
    before = {p.relative_to(work).as_posix(): controller.t.identity(p) for p in work.rglob("*") if p.is_file()}
    preserved = root / "preserved_work"
    work.rename(preserved)
    def forbidden(*args, **kwargs):
        raise AssertionError("cold restore must not refit or regenerate controls")
    monkeypatch.setattr(controller, "_worker", forbidden)
    monkeypatch.setattr(controller.control, "generate", forbidden)
    monkeypatch.setattr(controller.h, "batch_tree_prediction", forbidden)
    monkeypatch.setattr(controller.h, "fit_response_booster", forbidden)
    restored = controller.run(path, identity, root, durable, result["completion_index"], workers=2)
    assert restored == result
    after = {p.relative_to(work).as_posix(): controller.t.identity(p) for p in work.rglob("*") if p.is_file()}
    assert before == after


@pytest.mark.parametrize("defect", ("no_index", "wrong_index", "changed_plan", "missing_payload", "active_lock"))
def test_existing_state_never_silently_restarts(completed, tmp_path, monkeypatch, defect):
    root, durable, path, identity, _, result = completed
    expected = result["completion_index"]
    changed = None
    if defect == "no_index":
        expected = None
    elif defect == "wrong_index":
        expected = copy.deepcopy(expected)
        expected["identity"]["sha256"] = "0" * 64
    elif defect == "changed_plan":
        identity = dict(identity, sha256="0" * 64)
    elif defect == "missing_payload":
        changed = durable / "prepare_50.checkpoint.zip"
        changed.rename(tmp_path / changed.name)
    else:
        changed = root / "work/controller.lock"
        changed.write_text("another active owner", encoding="utf-8")
    def forbidden(*args, **kwargs):
        raise AssertionError("invalid resume cannot start workers")
    monkeypatch.setattr(controller, "run_window_jobs", forbidden)
    try:
        with pytest.raises((ValueError, FileNotFoundError, FileExistsError)):
            controller.run(path, identity, root, durable, expected)
    finally:
        if defect == "missing_payload":
            (tmp_path / changed.name).rename(changed)
        elif defect == "active_lock":
            assert changed.read_text(encoding="utf-8") == "another active owner"
            changed.unlink()


def test_execution_contract_rejects_missing_window_and_wrong_source(tmp_path):
    root = tmp_path / "runtime"
    path, _, plan = execution_plan(root)
    plan["windows"] = ["100"]
    with pytest.raises(ValueError, match="fixed_execution_plan"):
        controller.run(path, write_json(path, plan), root, tmp_path / "durable")
    plan["windows"] = ["50", "75", "100"]
    plan["incumbent"]["identity"]["sha256"] = "0" * 64
    with pytest.raises(ValueError, match="not_accepted_source"):
        controller.run(path, write_json(path, plan), root, tmp_path / "durable")
    assert not (root / "work").exists()


@pytest.mark.parametrize("workers", (True, 0, -1, 1.5, "2"))
def test_invalid_worker_count_rejected_before_inputs(tmp_path, workers):
    with pytest.raises(ValueError, match="positive_worker"):
        controller.run(tmp_path / "missing", {}, tmp_path / "runtime", tmp_path / "durable", workers=workers)


def test_checkpoint_seal_uses_producer_member_pins_not_current_resealed_hashes(tmp_path):
    work = tmp_path / "work"
    work.mkdir()
    payload, receipt_path = work / "model.json", work / "receipt.json"
    payload.write_bytes(b'{"tree":1}')
    receipt_path.write_bytes(b'{"completed":true}')
    members = {name: controller.t.identity(work / name) for name in ("model.json", "receipt.json")}
    payload.write_bytes(b'{"tree":2}')
    journal = controller.checkpoints.Journal(work, tmp_path / "durable", {"fixture": True})
    with pytest.raises(ValueError, match="byte_identity_mismatch"):
        controller.seal_unit(journal, "unit", "receipt.json", members["receipt.json"], members)
    assert not (tmp_path / "durable").exists()
