import copy
import json
import multiprocessing
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import sqlite3
import sys

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import stage7_joint_recipe_v1 as joint
from test_stage7_hierarchical_response_v1 import row, stamp


def job(tmp_path, window="50", partial_labels=False, unsupported_calibration=False):
    h, t = joint.h, joint.t
    labels = sorted([a + "@" + size for a in h.AGGRESSIVE for size in h.LABELS[h.SIZE]]
                    + [a + "@none" for a in h.LABELS[h.ACTION] if a not in h.AGGRESSIVE])
    limited = ["call@none", "raise@small", "raise@medium", "raise@large"]
    database = tmp_path / "source.sqlite"
    con = sqlite3.connect(database)
    con.execute("CREATE TABLE rows(ordinal INTEGER PRIMARY KEY,row_id TEXT UNIQUE,partition TEXT,compact_json TEXT)")
    bounds = {}
    for game_index in range(6):
        game = "g" + str(game_index)
        offset = game_index * 1000
        bounds[game] = [stamp(offset), stamp(offset + 999)]
        partition = "train" if game_index < 4 else "calibration" if game_index == 4 else "evaluation"
        game_labels = limited * 3 if partial_labels and partition == "train" else labels
        if unsupported_calibration and partition == "calibration":
            game_labels = ["bet@small", "bet@medium", "bet@large"] * 4
        for index, label in enumerate(game_labels):
            action, bucket = label.split("@")
            current = row(game_index * 100 + index, game=game, actor="seen", decision=offset + 10 + index * 10,
                          action=action, size={"small": .25, "medium": .75, "large": 1.5, "none": 0}[bucket])
            current.update(game_started_utc=bounds[game][0], game_completed_utc=bounds[game][1])
            current["public"]["pot_before_bb"] = 1 + index
            con.execute("INSERT INTO rows VALUES(?,?,?,?)", (game_index * 100 + index, current["row_id"], partition, json.dumps(current)))
    con.commit(); con.close()
    predecessor = dict(train_game_ids=["g0", "g1", "g2", "g3"], calibration_game_ids=["g4"], evaluation_game_ids=["g5"],
                       diagnostic_game_ids=[], model_config=dict(iterations=3, num_leaves=3, learning_rate=.1, min_child_samples=1, seed=17))
    protocol = h.development_protocol(predecessor, bounds)
    contract_path = tmp_path / "input_contract.json"
    contract = dict(schema_version=h.SCHEMA + "_input_contract_v2", authority=h.AUTHORITY,
                    evidence_class=h.EVIDENCE, execution_release=False, protocol=protocol, game_bounds=bounds)
    directory = tmp_path / "prepared"
    receipt = joint.prep.prepare(database, t.sha(database), protocol, bounds, directory, {"fixture": True}, window=window)
    x = np.random.default_rng(11).normal(size=(120, len(h.incumbent.PUBLIC_NAMES)))
    old_model = h.incumbent.fit_booster(x, np.arange(120) % len(labels), labels, predecessor["model_config"])
    exported = h.incumbent.booster_export(old_model, labels, h.incumbent.PUBLIC_NAMES)
    incumbent = tmp_path / "incumbent.json"
    t.publish_local_bytes(incumbent, (h.incumbent.canonical(dict(authority=h.AUTHORITY, models={joint.ROLE: exported})) + "\n").encode())
    contract["accepted_sources"] = {}
    for name in joint.ACCEPTED_SOURCE_NAMES:
        source = incumbent if name == "range_response_artifact.json" else tmp_path / "accepted" / name
        if source != incumbent:
            t.publish_local_bytes(source, (h.incumbent.canonical(predecessor if name == "protocol.json" else {"fixture": True}) + "\n").encode())
        contract["accepted_sources"][name] = dict(path="returned_results/03_range_r2/" + name, **t.identity(source))
    contract["compact_checkpoint"] = {"manifest": {"members": {"fit/prepared/rows.sqlite": t.identity(database)}}}
    t.publish_local_bytes(contract_path, (h.incumbent.canonical(contract) + "\n").encode())
    return dict(job_id="joint_" + window, window=window, protocol=protocol, output=str(tmp_path / "output"),
                input_contract_path=str(contract_path), input_contract_identity=t.identity(contract_path),
                prepared_directory=str(directory), preparation_binding=receipt["binding"],
                preparation_identity=t.identity(directory / "preparation_receipt.json"),
                incumbent_path=str(incumbent), incumbent_identity=t.identity(incumbent))


@pytest.mark.parametrize("window", ["50", "75"])
def test_short_window_recipe_and_resume_never_refits(tmp_path, monkeypatch, window):
    arguments = job(tmp_path, window)
    result = joint.fit_joint_job(arguments)
    output = Path(arguments["output"])
    report = joint.t.load(output / "scores.json")
    model = joint.t.load(output / "model.json")
    assert report["training_rows"] == (24 if window == "50" else 36)
    assert model["labels"] == sorted(model["labels"])
    assert model["model_config"] == arguments["protocol"]["model_config"]
    assert report["evaluation_supported_rows"] == 12
    assert report["unsupported_target_counts"] == {"calibration": {}, "evaluation": {}}
    assert report["full_window_refitted"] is False
    before = {p.name: p.read_bytes() for p in output.iterdir()}
    def forbidden(*args, **kwargs):
        raise AssertionError("completed joint job must not refit")
    monkeypatch.setattr(joint.h.incumbent, "fit_booster", forbidden)
    arguments["expected_job_receipt_identity"] = result["receipt"]
    assert joint.fit_joint_job(arguments)["reused"]
    assert before == {p.name: p.read_bytes() for p in output.iterdir()}


def test_unseen_joint_targets_are_reported_and_columns_remain_aligned(tmp_path):
    arguments = job(tmp_path, partial_labels=True)
    joint.fit_joint_job(arguments)
    output = Path(arguments["output"])
    report = joint.t.load(output / "scores.json")
    assert report["calibration_supported_rows"] == report["evaluation_supported_rows"] == 4
    assert sum(report["unsupported_target_counts"]["evaluation"].values()) == 8
    with np.load(output / "predictions.npz", allow_pickle=False) as values:
        assert values["candidate"].shape == (4, 12)
        excluded = [index for index, label in enumerate(report["labels"]) if label not in report["fitted_labels"]]
        assert np.all(values["candidate"][:, excluded] == 0)
        np.testing.assert_allclose(values["candidate"].sum(axis=1), 1)
        ll = -np.log(values["candidate"][np.arange(4), values["target"]]).mean()
        assert report["frozen_incumbent"]["log_loss"] == pytest.approx(ll)


def test_accepted_full_window_cannot_be_refitted(tmp_path, monkeypatch):
    arguments = job(tmp_path)
    arguments["window"] = "100"
    def forbidden(*args, **kwargs):
        raise AssertionError("full-window reuse must fail before input parsing or fitting")
    monkeypatch.setattr(joint, "verified_json", forbidden)
    with pytest.raises(ValueError, match="must_reuse_accepted_model"):
        joint.fit_joint_job(arguments)
    assert not Path(arguments["output"]).exists()


def test_missing_expected_receipt_and_dirty_output_fail_before_work(tmp_path, monkeypatch):
    arguments = job(tmp_path)
    arguments["expected_job_receipt_identity"] = {"bytes": 1, "sha256": "0" * 64}
    def forbidden(*args, **kwargs):
        raise AssertionError("invalid output cannot begin input processing")
    monkeypatch.setattr(joint, "inputs", forbidden)
    with pytest.raises(ValueError, match="expected_job_receipt_missing"):
        joint.fit_joint_job(arguments)
    arguments.pop("expected_job_receipt_identity")
    output = Path(arguments["output"]); output.mkdir()
    (output / "unowned.txt").write_text("preserve", encoding="utf-8")
    with pytest.raises(ValueError, match="unmanifested"):
        joint.fit_joint_job(arguments)
    assert (output / "unowned.txt").read_text(encoding="utf-8") == "preserve"


def test_changed_protocol_cannot_relabel_preparation(tmp_path):
    arguments = job(tmp_path)
    arguments["protocol"]["model_config"]["iterations"] = 5
    with pytest.raises(ValueError, match="protocol_input_contract_mismatch"):
        joint.fit_joint_job(arguments)


@pytest.mark.parametrize("defect", ["wrong_length", "nonprefix", "reordered_full_window"])
def test_audit_mislabeled_authenticated_preparation_cannot_change_window_recipe(tmp_path, monkeypatch, defect):
    arguments = job(tmp_path)
    protocol = arguments["protocol"]
    if defect == "wrong_length":
        protocol["training_windows"]["50"] = list(protocol["training_windows"]["75"])
    elif defect == "nonprefix":
        protocol["training_windows"]["50"] = ["g1", "g2"]
    else:
        protocol["training_windows"]["100"].reverse()
    contract = joint.t.load(arguments["input_contract_path"])
    contract["protocol"] = protocol
    # Even deliberate external authentication of a replacement cannot redefine
    # the window recipe. Rebuild the derivative just as the audit probe did.
    Path(arguments["input_contract_path"]).write_text(json.dumps(contract), encoding="utf-8")
    arguments["input_contract_identity"] = joint.t.identity(arguments["input_contract_path"])
    directory = tmp_path / "altered_preparation"
    receipt = joint.prep.prepare(tmp_path / "source.sqlite", joint.t.sha(tmp_path / "source.sqlite"), protocol,
                                 contract["game_bounds"], directory, {"fixture": True}, window="50")
    arguments.update(prepared_directory=str(directory), preparation_binding=receipt["binding"],
                     preparation_identity=joint.t.identity(directory / "preparation_receipt.json"))
    def forbidden(*args, **kwargs):
        raise AssertionError("mislabeled window must not reach fitting")
    monkeypatch.setattr(joint.h.incumbent, "fit_booster", forbidden)
    with pytest.raises(ValueError, match="exact_chronological_training_windows_required"):
        joint.fit_joint_job(arguments)
    assert not Path(arguments["output"]).exists()


@pytest.mark.parametrize("defect", ["report", "model", "model_boolean", "array", "receipt_parity"])
def test_resealed_semantic_mutations_fail_closed(tmp_path, defect):
    arguments = job(tmp_path)
    joint.fit_joint_job(arguments)
    output = Path(arguments["output"])
    if defect == "array":
        member = "predictions.npz"
        with np.load(output / member, allow_pickle=False) as stored:
            arrays = {name: stored[name] for name in stored.files}
        arrays["candidate"][0, 0] = float("nan")
        np.savez_compressed(output / member, **arrays)
    elif defect != "receipt_parity":
        member = "scores.json" if defect == "report" else "model.json"
        changed = joint.t.load(output / member)
        if defect == "model_boolean":
            changed["authority"]["promotion"] = 0
        else:
            changed["promotion"] = True
        (output / member).write_text(json.dumps(changed), encoding="utf-8")
    receipt = joint.t.load(output / "job_receipt.json")
    if defect == "receipt_parity":
        receipt["native_portable_parity_rows"] = 0
    else:
        receipt["members"][member] = joint.t.identity(output / member)
    (output / "job_receipt.json").write_text(json.dumps(receipt), encoding="utf-8")
    arguments["expected_job_receipt_identity"] = joint.t.identity(output / "job_receipt.json")
    with pytest.raises(ValueError):
        joint.fit_joint_job(arguments)


def test_no_supported_calibration_stops_before_fitting(tmp_path, monkeypatch):
    arguments = job(tmp_path, partial_labels=True, unsupported_calibration=True)
    def forbidden(*args, **kwargs):
        raise AssertionError("do not fit if the frozen calibration has no supported target")
    monkeypatch.setattr(joint.h.incumbent, "fit_booster", forbidden)
    with pytest.raises(ValueError, match="calibration_has_no_supported_targets"):
        joint.fit_joint_job(arguments)
    assert not Path(arguments["output"]).exists()


def test_audit_replacement_compatible_incumbent_cannot_bypass_accepted_anchor(tmp_path, monkeypatch):
    arguments = job(tmp_path)
    artifact = joint.t.load(arguments["incumbent_path"])
    tree = artifact["models"][joint.ROLE]["trees"]["tree_info"][0]["tree_structure"]
    while "leaf_value" not in tree:
        tree = tree["left_child"]
    tree["leaf_value"] += .5
    replacement = tmp_path / "compatible_replacement.json"
    replacement.write_text(json.dumps(artifact), encoding="utf-8")
    arguments.update(incumbent_path=str(replacement), incumbent_identity=joint.t.identity(replacement))
    actual = joint.verified_json
    def forbid_model_parse(path, expected):
        if Path(path) == replacement:
            raise AssertionError("nonaccepted incumbent must fail before parsing")
        return actual(path, expected)
    monkeypatch.setattr(joint, "verified_json", forbid_model_parse)
    with pytest.raises(ValueError, match="incumbent_not_accepted_input_contract_artifact"):
        joint.fit_joint_job(arguments)
    assert not Path(arguments["output"]).exists()


@pytest.mark.parametrize("defect", ["missing_source", "source_extra", "unsafe_source_path", "database_anchor"])
def test_audit_source_contract_inventory_and_database_anchor(tmp_path, monkeypatch, defect):
    arguments = job(tmp_path)
    contract = joint.t.load(arguments["input_contract_path"])
    if defect == "missing_source":
        contract["accepted_sources"].pop("range_response_report.json")
    elif defect == "source_extra":
        contract["accepted_sources"]["range_response_artifact.json"]["promotion"] = True
    elif defect == "unsafe_source_path":
        contract["accepted_sources"]["range_response_artifact.json"]["path"] = "../different.json"
    else:
        contract["compact_checkpoint"]["manifest"]["members"]["fit/prepared/rows.sqlite"]["sha256"] = "0" * 64
    Path(arguments["input_contract_path"]).write_text(json.dumps(contract), encoding="utf-8")
    arguments["input_contract_identity"] = joint.t.identity(arguments["input_contract_path"])
    def forbidden(*args, **kwargs):
        raise AssertionError("invalid accepted source lineage must not fit")
    monkeypatch.setattr(joint.h.incumbent, "fit_booster", forbidden)
    with pytest.raises(ValueError):
        joint.fit_joint_job(arguments)
    assert not Path(arguments["output"]).exists()


def test_identical_accepted_model_bytes_may_use_a_colab_staging_path(tmp_path):
    arguments = job(tmp_path)
    staged = tmp_path / "staged" / "accepted_model.json"
    staged.parent.mkdir()
    staged.write_bytes(Path(arguments["incumbent_path"]).read_bytes())
    arguments["incumbent_path"] = str(staged)
    assert not joint.fit_joint_job(arguments)["reused"]


def test_real_spawned_process_canary(tmp_path):
    arguments = job(tmp_path)
    with ProcessPoolExecutor(max_workers=1, mp_context=multiprocessing.get_context("spawn")) as pool:
        result = pool.submit(joint.fit_joint_job, arguments).result(timeout=60)
    assert result["receipt"] == joint.t.identity(Path(arguments["output"]) / "job_receipt.json")
