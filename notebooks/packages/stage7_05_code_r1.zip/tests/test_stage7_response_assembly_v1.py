import copy
from pathlib import Path
import shutil
import sys

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import stage7_response_assembly_v1 as assembly
from test_stage7_joint_recipe_v1 import job


def write_json(path, value):
    Path(path).write_text(assembly.h.incumbent.canonical(value) + "\n", encoding="utf-8")
    return assembly.t.identity(path)


def completed_plan(directory, window):
    directory.mkdir(exist_ok=True)
    arguments = job(directory, window, partial_labels=True)
    plan = dict(schema_version=assembly.SCHEMA + "_plan", window=window,
                input_contract=dict(path=arguments["input_contract_path"], identity=arguments["input_contract_identity"]),
                preparation=dict(directory=arguments["prepared_directory"], identity=arguments["preparation_identity"]), jobs={})
    for role in assembly.h.ROLES:
        for arm in assembly.h.ARMS:
            name = role + "/" + arm
            current = {key: value for key, value in arguments.items() if key in assembly.BASE_ARGUMENTS}
            current.update(job_id=role + "_" + arm + "_" + window, role=role, arm=arm,
                           output=str(directory / (role + "_" + arm)))
            completion = assembly.runner.fit_job(current)
            plan["jobs"][name] = dict(arguments=current, receipt_identity=completion["receipt"])
    if window != "100":
        completion = assembly.joint.fit_joint_job(arguments)
        plan["jobs"]["same_recipe"] = dict(arguments=arguments, receipt_identity=completion["receipt"])
    path = directory / "assembly_plan.json"
    identity = write_json(path, plan)
    return path, identity, plan


@pytest.fixture(scope="module", params=("50", "75", "100"))
def completed(tmp_path_factory, request):
    return completed_plan(tmp_path_factory.mktemp("assembly_" + request.param), request.param)


def test_complete_worker_outputs_assemble_without_fit_replay_or_writes(completed, monkeypatch):
    path, identity, plan = completed
    before = {p.relative_to(path.parent).as_posix(): assembly.t.identity(p) for p in path.parent.rglob("*") if p.is_file()}
    def forbidden(*args, **kwargs):
        raise AssertionError("assembly may not fit, replay, prepare or publish")
    monkeypatch.setattr(assembly.runner, "fit_job", forbidden)
    monkeypatch.setattr(assembly.joint, "fit_joint_job", forbidden)
    monkeypatch.setattr(assembly.prep, "prepare", forbidden)
    monkeypatch.setattr(assembly.h, "batch_tree_prediction", forbidden)
    monkeypatch.setattr(assembly.h, "fit_response_booster", forbidden)
    monkeypatch.setattr(assembly.t, "publish_local_bytes", forbidden)
    result = assembly.assemble_window(path, identity)
    assert result["plan_identity"] == identity
    assert not result["model_fitting_performed"] and not result["model_replay_performed"]
    assert not result["preparation_performed"]
    assert len(result["completion_identities"]) == (8 if plan["window"] == "100" else 9)
    for role, expected_full, expected_short in ((assembly.h.ACTION, 12, 4), (assembly.h.SIZE, 9, 3)):
        compared = result["roles"][role]
        count = expected_full if plan["window"] == "100" else expected_short
        assert compared["role_rows"] == expected_full and compared["common_rows"] == count
        assert len(compared["excluded_role_row_ids"]) == expected_full - count
        assert len(compared["comparisons"]) == 7 and compared["selected_winner"] is None
        for score in compared["comparisons"].values():
            assert score["rows"] == count
            assert score["familywise_confirmation_claim"] is False
    after = {p.relative_to(path.parent).as_posix(): assembly.t.identity(p) for p in path.parent.rglob("*") if p.is_file()}
    assert before == after


def test_wrong_plan_hash_fails_before_json_parsing(completed, monkeypatch):
    path, identity, _ = completed
    def forbidden(*args, **kwargs):
        raise AssertionError("unauthenticated JSON must not be parsed")
    monkeypatch.setattr(assembly.auth, "parse_json", forbidden)
    with pytest.raises(ValueError, match="byte_identity_mismatch"):
        assembly.assemble_window(path, dict(identity, sha256="0" * 64))


@pytest.mark.parametrize("defect", ("missing_job", "extra_job", "duplicate_output", "duplicate_job_id",
                                   "wrong_window", "wrong_role_arm", "replacement_incumbent", "missing_external_receipt",
                                   "bad_receipt_hash", "missing_receipt", "changed_recipe", "changed_preparation_identity"))
def test_incomplete_or_mixed_completions_fail_closed(completed, tmp_path, defect):
    _, _, original = completed
    plan = copy.deepcopy(original)
    name = assembly.h.ACTION + "/public_only"
    entry = plan["jobs"][name]
    if defect == "missing_job":
        del plan["jobs"][name]
    elif defect == "extra_job":
        plan["jobs"]["unexpected"] = copy.deepcopy(entry)
    elif defect == "duplicate_output":
        entry["arguments"]["output"] = plan["jobs"][assembly.h.ACTION + "/population"]["arguments"]["output"]
    elif defect == "duplicate_job_id":
        entry["arguments"]["job_id"] = plan["jobs"][assembly.h.ACTION + "/population"]["arguments"]["job_id"]
    elif defect == "wrong_window":
        plan["window"] = "75" if original["window"] == "50" else "50"
    elif defect == "wrong_role_arm":
        entry["arguments"]["arm"] = "player"
    elif defect == "replacement_incumbent":
        entry["arguments"]["incumbent_identity"] = {"bytes": 20, "sha256": "0" * 64}
    elif defect == "missing_external_receipt":
        entry["receipt_identity"] = None
    elif defect == "bad_receipt_hash":
        entry["receipt_identity"]["sha256"] = "0" * 64
    elif defect == "missing_receipt":
        entry["arguments"]["output"] = str(tmp_path / "never_started")
    elif defect == "changed_recipe":
        # Avoid sharing the fixture's protocol with sibling plan arguments.
        entry["arguments"]["protocol"] = dict(entry["arguments"]["protocol"], model_config={"iterations": 9})
    elif defect == "changed_preparation_identity":
        entry["arguments"]["preparation_identity"] = {"bytes": 20, "sha256": "0" * 64}
    path = tmp_path / "plan.json"
    identity = write_json(path, plan)
    with pytest.raises((ValueError, FileNotFoundError)):
        assembly.assemble_window(path, identity)
    assert not (tmp_path / "never_started").exists()


def changed_completion(plan, name, tmp_path, mutate):
    entry = plan["jobs"][name]
    output = tmp_path / "changed_completion"
    shutil.copytree(entry["arguments"]["output"], output)
    entry["arguments"]["output"] = str(output)
    receipt = assembly.t.load(output / "job_receipt.json")
    receipt["binding"]["output"] = str(output)
    mutate(output, receipt)
    receipt["members"] = {name: assembly.t.identity(output / name) for name in receipt["members"]}
    entry["receipt_identity"] = write_json(output / "job_receipt.json", receipt)


@pytest.mark.parametrize("defect", ("model_role", "model_cohort", "extra_member", "wrong_ordinal", "wrong_target",
                                   "wrong_game", "float_target", "frozen_comparator_divergence", "source_code_hash"))
def test_resealed_completion_cannot_hide_semantic_or_inventory_errors(completed, tmp_path, defect):
    _, _, original = completed
    plan = copy.deepcopy(original)
    def mutate(output, receipt):
        if defect in ("model_role", "model_cohort"):
            model = assembly.t.load(output / "model.json")
            if defect == "model_role":
                model["role"] = assembly.h.SIZE
            else:
                model["trained_game_ids"] = ["g0"]
            write_json(output / "model.json", model)
        elif defect == "extra_member":
            (output / "unlisted.txt").write_text("preserve", encoding="utf-8")
        elif defect == "source_code_hash":
            receipt["binding"]["source_hashes"]["stage7_hierarchical_response_v1.py"] = "0" * 64
        else:
            with np.load(output / "predictions.npz", allow_pickle=False) as stored:
                values = {name: stored[name] for name in stored.files}
            if defect == "wrong_ordinal":
                values["ordinal"][0] += 1
            elif defect == "wrong_target":
                values["target"][0] = (values["target"][0] + 1) % 6
            elif defect == "wrong_game":
                values["game_id"][0] = "g0"
            elif defect == "float_target":
                values["target"] = values["target"].astype(np.float64)
            else:
                values["frozen_incumbent"] = np.roll(values["frozen_incumbent"], 1, axis=1)
            np.savez_compressed(output / "predictions.npz", **values)
    changed_completion(plan, assembly.h.ACTION + "/player", tmp_path, mutate)
    path = tmp_path / "plan.json"
    identity = write_json(path, plan)
    with pytest.raises(ValueError):
        assembly.assemble_window(path, identity)


def test_no_joint_refit_completion_is_accepted_for_full_window(completed, tmp_path):
    _, _, original = completed
    plan = copy.deepcopy(original)
    if plan["window"] != "100":
        del plan["jobs"]["same_recipe"]
    else:
        plan["jobs"]["same_recipe"] = copy.deepcopy(plan["jobs"][assembly.h.ACTION + "/public_only"])
    path = tmp_path / "plan.json"
    identity = write_json(path, plan)
    with pytest.raises(ValueError, match="complete_fixed_job_family_required"):
        assembly.assemble_window(path, identity)
